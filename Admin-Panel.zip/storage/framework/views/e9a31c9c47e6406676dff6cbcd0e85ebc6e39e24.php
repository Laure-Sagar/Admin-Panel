    <div>
        This is just text for div in inline in livewire!
    </div><?php /**PATH C:\Users\hp\OneDrive\Documents\GitHub\Admin-Panel\storage\framework\views/459da9def3bfd2b4c45e558aadb3ed25edf01b3b.blade.php ENDPATH**/ ?>