<div>
    <?php echo e($text); ?>

    <form wire.submit.prevent='update'>
        <input type="text" wire:model.debounce.700ms="sub">
        <button type="submit" wire:click="foo">Test</button>
    </form>
</div><?php /**PATH C:\Users\hp\OneDrive\Documents\GitHub\Admin-Panel\resources\views/livewire/post/show.blade.php ENDPATH**/ ?>