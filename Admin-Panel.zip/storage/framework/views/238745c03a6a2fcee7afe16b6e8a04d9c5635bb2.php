<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document | <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('post.show', [])->html();
} elseif ($_instance->childHasBeenRendered('8FjuMVL')) {
    $componentId = $_instance->getRenderedChildComponentId('8FjuMVL');
    $componentTag = $_instance->getRenderedChildComponentTagName('8FjuMVL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8FjuMVL');
} else {
    $response = \Livewire\Livewire::mount('post.show', []);
    $html = $response->html();
    $_instance->logRenderedChild('8FjuMVL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php echo \Livewire\Livewire::styles(); ?>

</body>
</html><?php /**PATH C:\Users\hp\OneDrive\Documents\GitHub\Admin-Panel\resources\views/layouts/app.blade.php ENDPATH**/ ?>