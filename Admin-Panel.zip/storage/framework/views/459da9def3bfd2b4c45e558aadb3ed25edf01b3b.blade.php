    <div>
        This is just text for div in inline in livewire!
    </div>