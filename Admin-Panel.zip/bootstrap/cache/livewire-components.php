<?php return array (
  'like.show' => 'App\\Http\\Livewire\\Like\\Show',
  'post.show' => 'App\\Http\\Livewire\\Post\\Show',
);